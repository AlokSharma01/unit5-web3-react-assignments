import React from 'react'

export const List1 = () => {
  return (
    <div>
        <ul>
            <li>Android</li>
            <li>BlackBerry</li>
            <li>iPhone</li>
            <li>Windos Phone</li>
        </ul>
    </div>
  )
}

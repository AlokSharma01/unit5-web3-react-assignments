import React from 'react'

export const List2 = () => {
  return (
    <div>
        <ul>
            <li>Samsung</li>
            <li>HTC</li>
            <li>MicroMax</li>
            <li>Apple</li>
        </ul>
    </div>
  )
}
